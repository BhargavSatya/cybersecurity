<!--
If this is a bug report please fill out the template below.

If this is a feature request please describe the behavior that you'd like to see.
-->

**Environment**:

  - CTFd Version/Commit:
  - Operating System:
  - Web Browser and Version:

**What happened?**

**What did you expect to happen?**

**How to reproduce your issue**

**Any associated stack traces or error logs**

