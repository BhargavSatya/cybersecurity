import random
import time

currentTime = str(time.time())
random.seed(currentTime)
msg = raw_input('Plaintext Message: ')
key = [ord(c) for c in currentTime] + [random.randrange(256) for _ in msg]  # concatenate ascii values of str(currentTime) with list of random integers
key = key[:len(msg)]                                                        # trim key to len(msg)
cipher = [chr(ord(m)^s) for (m,s) in zip(msg, key)]                         # xor each character in message with integer in key
cipher = ''.join(cipher)                                                    # join the list into a string

print('Encrypted message: ' + cipher.encode('hex'))                         # print the hex encoded string
